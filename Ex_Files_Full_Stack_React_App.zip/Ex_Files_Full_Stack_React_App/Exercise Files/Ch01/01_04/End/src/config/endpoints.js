export const relayApi = 'https://api.graph.cool/relay/v1/ciyn8rxsl3bs201324sbzf0hx'
