import React, {Component} from 'react'

class Profile extends Component {

  render() {
    return (
      <div>
        <h2>Profile!</h2>
      </div>
    )
  }
}

export default Profile
