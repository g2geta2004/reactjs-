import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(
  <div>
    <h1>Hello world!</h1>
  </div>,
  document.getElementById('root')
)
